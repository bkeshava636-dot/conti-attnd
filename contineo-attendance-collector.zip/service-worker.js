/**
 * Contineo Attendance Collector - Service Worker (Manifest V3)
 * Handles lifecycle, alarms, and automatic background roster synchronization.
 */

const ALARM_NAME = 'CONTINEO_AUTO_SYNC';

chrome.runtime.onInstalled.addListener(async () => {
  console.log('[Contineo Attendance Collector] Service worker initialized v1.3.0.');
  
  // Default configuration
  const defaults = {
    backendUrl: 'https://conti-attnd.vercel.app',
    proctorToken: 'demo-proctor-secret-key-bitm',
    pageAutoSyncEnabled: true,
    autoSyncEnabled: false,
    autoSyncInterval: 30, // minutes
    lastAutoSyncTimestamp: null,
    lastSyncCount: 0
  };

  const stored = await chrome.storage.local.get(Object.keys(defaults));
  const toSet = {};
  for (const [key, val] of Object.entries(defaults)) {
    if (stored[key] === undefined) {
      toSet[key] = val;
    }
  }
  if (Object.keys(toSet).length > 0) {
    await chrome.storage.local.set(toSet);
  }

  // Restore alarm if enabled
  if (stored.autoSyncEnabled) {
    chrome.alarms.create(ALARM_NAME, {
      periodInMinutes: parseInt(stored.autoSyncInterval || 30, 10)
    });
  }

  await chrome.action.setBadgeText({ text: '' });
});

// Update badge when a Contineo tab becomes active
chrome.tabs.onActivated.addListener(async (activeInfo) => {
  try {
    const tab = await chrome.tabs.get(activeInfo.tabId);
    if (tab && tab.url && (tab.url.includes('contineo.in') || tab.url.includes('contineo-sims-fixture') || tab.url.includes('/fixture'))) {
      await chrome.action.setBadgeText({ text: 'ON' });
      await chrome.action.setBadgeBackgroundColor({ color: '#2563eb' });
    } else {
      await chrome.action.setBadgeText({ text: '' });
    }
  } catch (err) {
    // Tab closed
  }
});

// Listen for popup messages to control Auto-Sync alarm and page detection
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'SET_AUTO_SYNC') {
    const { enabled, intervalMinutes } = message;
    if (enabled) {
      chrome.alarms.create(ALARM_NAME, {
        periodInMinutes: parseInt(intervalMinutes, 10)
      });
      console.log(`[Auto-Sync] Scheduled every ${intervalMinutes} minutes.`);
    } else {
      chrome.alarms.clear(ALARM_NAME);
      console.log('[Auto-Sync] Background schedule cancelled.');
    }
    sendResponse({ success: true });
    return true;
  }

  if (message.action === 'SET_PAGE_AUTO_SYNC') {
    chrome.storage.local.set({ pageAutoSyncEnabled: !!message.enabled });
    console.log(`[Auto-Sync] Page detection auto-sync set to ${!!message.enabled}.`);
    sendResponse({ success: true });
    return true;
  }

  if (message.action === 'AUTO_DETECTED_PAGE_SYNC') {
    handleAutoDetectedSync(message.report, sender.tab).then(sendResponse);
    return true; // Keep channel open for async response
  }
});

/**
 * Handle auto-detected student attendance from page content script
 */
async function handleAutoDetectedSync(report, tab) {
  if (!report || !report.students || !report.students.length) {
    return { success: false, error: 'Empty student report' };
  }

  const validStudents = report.students.filter(s => s.usn && Array.isArray(s.subjects) && s.subjects.length > 0);
  if (validStudents.length === 0) {
    return { success: false, error: 'No valid students found in report' };
  }

  const config = await chrome.storage.local.get(['backendUrl', 'proctorToken']);
  const backendUrl = config.backendUrl || 'https://conti-attnd.vercel.app';
  const proctorToken = config.proctorToken || 'demo-proctor-secret-key-bitm';

  const payload = {
    proctorId: 'proctor-bitm-cse-01',
    semester: validStudents[0]?.semester || 'SEM03',
    sourceUrl: tab?.url || report.url || 'https://bitm.contineo.in',
    extractedAt: new Date().toISOString(),
    students: validStudents,
    diagnostics: {
      autoSync: true,
      trigger: 'page_detection',
      totalDetected: report.diagnostics?.totalSectionsDetected || validStudents.length
    }
  };

  let res = null;
  try {
    res = await fetch(`${backendUrl}/api/attendance/publish`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${proctorToken}`
      },
      body: JSON.stringify(payload)
    });
  } catch (err) {
    res = null;
  }

  if (res && res.ok) {
    console.log(`[Page Auto-Sync] Successfully published ${validStudents.length} students at ${new Date().toLocaleTimeString()}`);
    await chrome.storage.local.remove(['offlinePendingPayload']);
    await chrome.storage.local.set({
      lastAutoSyncTimestamp: new Date().toISOString(),
      lastSyncCount: validStudents.length,
      lastReport: report
    });

    // Visual badge confirmation
    await chrome.action.setBadgeText({ text: '✓' });
    await chrome.action.setBadgeBackgroundColor({ color: '#10b981' });
    setTimeout(async () => {
      await chrome.action.setBadgeText({ text: 'ON' });
      await chrome.action.setBadgeBackgroundColor({ color: '#2563eb' });
    }, 4000);

    return { success: true, count: validStudents.length, queuedOffline: false };
  } else if (!res || res.status >= 500 || [401, 403, 404, 408, 429].includes(res.status)) {
    console.warn(`[Page Auto-Sync] Server offline or busy, saving to offline queue.`);
    await chrome.storage.local.set({
      offlinePendingPayload: {
        id: payload.extractedAt || new Date().toISOString(),
        payload,
        queuedAt: new Date().toISOString(),
        studentCount: validStudents.length
      }
    });

    await chrome.action.setBadgeText({ text: 'WAIT' });
    await chrome.action.setBadgeBackgroundColor({ color: '#f59e0b' });

    return { success: true, count: validStudents.length, queuedOffline: true };
  }

  return { success: false, error: `Publish rejected (HTTP ${res ? res.status : 'Unknown'})` };
}

// Alarm Trigger: Automated Background Extraction
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name !== ALARM_NAME) return;
  console.log('[Auto-Sync] Alarm triggered, scanning for open Contineo SIMS tabs...');

  try {
    const config = await chrome.storage.local.get([
      'backendUrl', 
      'proctorToken', 
      'autoSyncEnabled'
    ]);

    if (!config.autoSyncEnabled) {
      chrome.alarms.clear(ALARM_NAME);
      return;
    }

    const backendUrl = config.backendUrl || 'https://conti-attnd.vercel.app';
    const proctorToken = config.proctorToken || 'demo-proctor-secret-key-bitm';

    // Flush any pending offline queue first
    await flushOfflineQueue(backendUrl, proctorToken);

    // Find any open Contineo tab
    const tabs = await chrome.tabs.query({});
    const targetTab = tabs.find(t => 
      t.url && (t.url.includes('contineo.in') || t.url.includes('contineo-sims-fixture') || t.url.includes('/fixture'))
    );

    if (!targetTab) {
      console.log('[Auto-Sync] No active Contineo SIMS tab open in browser. Skipping this cycle.');
      return;
    }

    console.log(`[Auto-Sync] Found eligible tab (${targetTab.id}): ${targetTab.url}`);

    // Request extraction from content script
    chrome.tabs.sendMessage(targetTab.id, { action: 'EXTRACT_ATTENDANCE' }, async (response) => {
      if (chrome.runtime.lastError || !response || !response.report || !response.report.students.length) {
        console.warn('[Auto-Sync] Tab not on attendance roster or extraction returned empty.');
        return;
      }

      const { students, diagnostics } = response.report;
      const validStudents = students.filter(s => s.usn && Array.isArray(s.subjects) && s.subjects.length > 0);

      if (validStudents.length === 0) return;

      const payload = {
        proctorId: 'proctor-bitm-cse-01',
        semester: validStudents[0]?.semester || 'SEM03',
        sourceUrl: targetTab.url,
        extractedAt: new Date().toISOString(),
        students: validStudents,
        diagnostics: {
          autoSync: true,
          totalDetected: diagnostics?.totalSectionsDetected || validStudents.length
        }
      };

      let res = null;
      try {
        res = await fetch(`${backendUrl}/api/attendance/publish`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${proctorToken}`
          },
          body: JSON.stringify(payload)
        });
      } catch (netErr) {
        res = null;
      }

      if (res && res.ok) {
        console.log(`[Auto-Sync] Successfully synced ${validStudents.length} students at ${new Date().toLocaleTimeString()}`);
        
        await chrome.storage.local.remove(['offlinePendingPayload']);
        await chrome.storage.local.set({
          lastAutoSyncTimestamp: new Date().toISOString(),
          lastSyncCount: validStudents.length
        });

        // Show brief visual feedback on badge
        await chrome.action.setBadgeText({ text: 'SYNC' });
        await chrome.action.setBadgeBackgroundColor({ color: '#10b981' });
        setTimeout(async () => {
          await chrome.action.setBadgeText({ text: 'ON' });
          await chrome.action.setBadgeBackgroundColor({ color: '#2563eb' });
        }, 5000);
      } else if (!res || res.status >= 500 || [401, 403, 404, 408, 429].includes(res.status)) {
        console.warn(`[Auto-Sync] Server returned ${res ? 'HTTP ' + res.status : 'network error'}, caching to offline queue.`);
        await chrome.storage.local.set({
          offlinePendingPayload: {
            id: payload.extractedAt || new Date().toISOString(),
            payload,
            queuedAt: new Date().toISOString(),
            studentCount: validStudents.length
          }
        });
        await chrome.action.setBadgeText({ text: 'WAIT' });
        await chrome.action.setBadgeBackgroundColor({ color: '#f59e0b' });
      } else {
        console.warn(`[Auto-Sync] Publish rejected by server (HTTP ${res.status}). Discarding rejected payload.`);
      }
    });

  } catch (err) {
    console.error('[Auto-Sync Error]:', err);
  }
});

async function flushOfflineQueue(backendUrl, proctorToken) {
  try {
    const data = await chrome.storage.local.get(['offlinePendingPayload']);
    if (!data.offlinePendingPayload || !data.offlinePendingPayload.payload) return;

    const { payload, studentCount } = data.offlinePendingPayload;
    const queueBatchId = data.offlinePendingPayload.id || data.offlinePendingPayload.queuedAt || '';

    const removeIfMatching = async () => {
      const current = await chrome.storage.local.get(['offlinePendingPayload']);
      const currentId = current?.offlinePendingPayload?.id || current?.offlinePendingPayload?.queuedAt || '';
      if (currentId === queueBatchId) {
        await chrome.storage.local.remove(['offlinePendingPayload']);
      }
    };

    console.log(`[Auto-Sync Worker] Attempting to flush offline queue (${studentCount} students)...`);

    const res = await fetch(`${backendUrl}/api/attendance/publish`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${proctorToken}`
      },
      body: JSON.stringify(payload)
    });

    if (res.ok) {
      await removeIfMatching();
      console.log(`[Auto-Sync Worker] Offline queue successfully uploaded to cloud.`);
      await chrome.action.setBadgeText({ text: 'SYNC' });
      await chrome.action.setBadgeBackgroundColor({ color: '#10b981' });
      setTimeout(async () => {
        await chrome.action.setBadgeText({ text: 'ON' });
        await chrome.action.setBadgeBackgroundColor({ color: '#2563eb' });
      }, 5000);
    } else if (res.status >= 400 && res.status < 500) {
      const discard = [400, 422].includes(res.status);
      if (discard) {
        console.warn(`[Auto-Sync Worker] Queued batch rejected by schema validator (HTTP ${res.status}). Discarding invalid payload.`);
        await removeIfMatching();
      } else {
        console.warn(`[Auto-Sync Worker] Server returned HTTP ${res.status} (Destination/Auth/Rate limit). Preserving offline queue.`);
      }
    }
  } catch (err) {
    console.warn('[Auto-Sync Worker] Offline flush deferred:', err.message);
  }
}
